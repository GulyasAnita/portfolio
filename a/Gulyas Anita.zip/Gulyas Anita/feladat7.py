import renszarvas
import string

lista=[]

def beolvas():
    #fájl elérése
    beFajlom=open("fajlok/Mikulasszan.txt","r",encoding="utf-8")
    #első sor eldobása
    beFajlom.readline()
    #többi sor
    adatok=beFajlom.readlines()
    #print(adatok)
    #beolvasott sorok feldolgozása
    for sor in adatok:
        #sorvégjelektől megtísztitom
        sor=sor.strip()
        #eldarabolom
        darabolt=sor.split("@")
        #print(darabolt)
        #példányosítás
        szarvas=renszarvas.Renszarvas(darabolt[0],darabolt[1],darabolt[2],darabolt[3])
        #print(szarvas)
        #listába fűzöm az objektumokat
        lista.append(szarvas)
        #erőforrás lezárása
        beFajlom.close()

def kiir():
    #utasok kiírása
    for szarvas in lista:
        print(szarvas)

def kiir2():
    for utas in lista:
        print(utas.magyarNev," – ",utas.angolNev,"magassága:",utas.magassag)

def renszarvasokSzama():
    #Hány rénszarvasa van a mikulásnak?
    #A lista hossza minusz a mikulás
    print("A rénszarvasok száma:",len(lista)-1)

def idegenPompas():
    for utas in lista:
        if utas.magyarNev=="Pompás":
            idegenNev=utas.angolNev
    return idegenNev


def irasjel_eltavolitas(szoveg):
    irasjel_nelkuli = ""
    for karakter in szoveg:
        if karakter not in irasjelek:
            irasjel_nelkuli += karakter
    return irasjel_nelkuli

def mikulasSzam():
        # összegzés
        osszeg = 0
    for utas in lista:
        tisztaUtas=irasjel_eltavolitas(utas.leiras)
        daraboltLeiras=tisztaUtas.split(" ")
        for szo in daraboltLeiras:
            if szo=="Mikulás":
                db+=1
    print("A Mikulás szó a leírásokban:",db,"számszor fordul elő")


def mikulas():
    print(
    """"
\tA feladathoz az adatokat a Mikulassszan.txt állományban találod. Ez egy rövid nyilvántartás, arról, hogy ki utazik a szánon.
\t1.	Olvasd be a mikulás rénszarvasainak adatait! 
\ta.	Írd ki a nevüket és a magasságukat.
\tb.	Hány rénszarvasa van a mikulásnak?
\tc.	Írd ki Pompás idegen nyelvű megfelelőjét!
\td.	A rénszarvas leírásokban hányszor fordul elő a Mikulás szó?
\te.	Átlagosa milyen magasak a rénszarvasok?
\tf.	Írd ki a páros helyen repülő szarvasok magyar nevét!
\tg.	Hányadik rénszarvasnak a leghosszabb a kiírása? (Kinek a leírása áll a legtöbb karakterből?)
\th.	Ki repül a legkisebb sorszámú helyen?

    """
)
    #szarvas1=renszarvas.Renszarvas("Comet – Üstökös","140","2","A Blorouis üstökös után kapta a nevét. Abban az időben ez vezette a csapatot a sötét és ködös éjszakán. Már az iskolában is kitűnő tanuló volt, a Mikulás igazi támaszának számított. Néha nagyon makacs, de erős. Különleges vezetői képességekkel rendelkezik, mindig a problémára összpontosít.")
    #print(szarvas1)
beolvas()
kiir()
kiir2()
renszarvasokSzama()
print("Pompás idegen neve: ",idegenPompas(),".")
irasjel_eltavolitas()
mikulasSzam()
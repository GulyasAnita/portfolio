import feladat7

print("7.feladat:")
feladat7.mikulas()


